/*
*Author: Timothy Khan (1239165)
*Date: March 19, 2023
*Assignment 5: 2 to 3
*
*The purpose of this program is to create circles with a radius to be inputted
*
*/
package a5q2to3;

public class Circle implements Comparable<Circle> 
{
    private double radius;

    // Constructor for Circle class
    public Circle(double radius) 
    {
        this.radius = radius;
    }

    // Getter for radius
    public double getRadius() 
    {
        return radius;
    }

    // Setter for radius
    public void setRadius(double radius) 
    {
        this.radius = radius;
    }

    // Implementation of the compareTo method from the Comparable interface
    @Override
    public int compareTo(Circle other) 
    {
        // Compare the radii of this Circle and the other Circle
        if (this.radius < other.radius) 
        {
            return -1; // this Circle is smaller than the other Circle
        } else if (this.radius > other.radius) 
        {
            return 1; // this Circle is larger than the other Circle
        } else 
        {
            return 0; // the two Circles have the same radius
        }
    }
}
