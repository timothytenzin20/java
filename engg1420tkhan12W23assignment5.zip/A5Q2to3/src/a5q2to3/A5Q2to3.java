/*
*Author: Timothy Khan (1239165)
*Date: March 19, 2023
*Assignment 5: 2-3
*
*The purpose of this program is to utilize the created circle and student classes to then compare the created objects
*
*/

package a5q2to3;

public class A5Q2to3 
{

public static void main(String[] args) 
{
    // Create some circles
    Circle c1 = new Circle(5.0);
    Circle c2 = new Circle(2.0);
    Circle c3 = new Circle(5.0);

    // Compare the circles based on their radii
    System.out.println("c1 compared to c2: " + c1.compareTo(c2)); // expected output: 1
    System.out.println("c2 compared to c3: " + c2.compareTo(c3)); // expected output: -1
    System.out.println("c1 compared to c3: " + c1.compareTo(c3)); // expected output: 0

    // Create some students
    Student s1 = new Student("John", "Doe", 12345, 3.5);
    Student s2 = new Student("Jane", "Doe", 54321, 3.9);
    Student s3 = new Student("John", "Doe", 12345, 3.5);

    // Compare the students based on their GPA values
    System.out.println("s1 compared to s2: " + s1.compareTo(s2)); // expected output: -1
    System.out.println("s2 compared to s3: " + s2.compareTo(s3)); // expected output: 1
    System.out.println("s1 compared to s3: " + s1.compareTo(s3)); // expected output: 0
}

}
