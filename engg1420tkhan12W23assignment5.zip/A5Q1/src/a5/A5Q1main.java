/*
*Author: Timothy Khan (1239165)
*Date: March 19, 2023
*Assignment 5: 1
*
*The purpose of this program is to create tickets according to the created classes and methods
*/
package a5;
import java.time.LocalDateTime;

public class A5Q1main 
{
    public static void main(String[] args) 
    {
        //Create sample passengers
        Person person1 = new Person("Name", "Surname", 000000000);
        Person person2 = new Person("Name", "Surname", 000000000);

        //Create sample tickets
        TrainTicket ticket1 = new TrainTicket(person1, "City A", "City B", LocalDateTime.now());
        TrainTicket ticket2 = new TrainTicket(person2, "City C", "City D", LocalDateTime.now());

        ticket1.add(person1, 2);
        ticket2.add(person2, 2);
    }
}
