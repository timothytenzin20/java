/*
*Author: Timothy Khan (1239165)
*Date: March 19, 2023
*Assignment 5: 1
*
*The purpose of this program is to create the ticket class and all its required methods 
*
*/

// Package declaration for class organization
package a5;

// Importing necessary classes
import java.time.*;
import java.util.ArrayList;

// Ticket class definition
class Ticket 
{
// Class variables for ticket management
private static int ticketcounter = 0;
private static ArrayList<Ticket> allTickets = new ArrayList<>();
private final int price = 0;
private final int capacity = 0;

// Instance variables for ticket data
protected String name;
protected String lastname;
protected int nationalCode;
protected String source;
protected String destination;
protected LocalDateTime departureTime;
protected String marker;

// Constructor for ticket creation
public Ticket(Person person, String source, String destination, LocalDateTime departureTime) 
{
    // Setting instance variables
    this.source = source;
    this.destination = destination;
    this.departureTime = departureTime;
    this.name = person.getName();
    this.lastname = person.getLastname();
    this.nationalCode = person.getNationalcode();
    // Setting the ticket marker
    this.marker = setMarker();
}

// Method for getting the discounted price of a ticket
public double getDiscountedPrice(int n) 
{
    double discountedPrice = getPrice() * n;
    if (n >= 5) {
        int discountPercent = (n / 5) + 1;
        if (discountPercent > 5) {
            discountPercent = 5;
        }
        discountedPrice *= (1 - (discountPercent / 100.0));
    }
    return discountedPrice;
}

// Method for printing all tickets made and the total price
public void print(double price) 
{
    System.out.println("Number of tickets made: " + ticketcounter);
    System.out.println("Total Price " + price);
    for (Ticket ticket : allTickets) 
    {
        System.out.println(ticket.toString());
    }
}

// Method for adding a ticket for a person
public void add(Person person) 
{
    add(person, 1);
}

// Method for adding a specified number of tickets for a person
public void add(Person person, int n) 
{
    // Check if the vehicle capacity is exceeded
    if (getCounter() + n > getCapacity()) 
    {
        System.out.println("Error: Vehicle capacity exceeded");
        return;
    }
    // Create n number of tickets for the person
    for (int i = 0; i < n; i++) 
    {
        Ticket ticket = new Ticket(person, source, destination, departureTime) {};
        allTickets.add(ticket);
        setCounter(getCounter() + 1);
    }
    // Print the total price for the added tickets
    double price = getDiscountedPrice(n);
    print(price);
}

// Method for setting the ticket marker
public String setMarker() 
{
    LocalDateTime now = LocalDateTime.now();
    String date = String.format("%04d%02d%02d", now.getYear(), now.getMonthValue(), now.getDayOfMonth());
    return String.format("%s%s%s", getVehicleType(), date, getCounter() + 1);
}

// Method for getting the vehicle type
public String getVehicleType()
{
    return "";
}

// Method for getting the ticket price
public int getPrice()
{
    return 0;
}

// Method for getting the vehicle capacity
public int getCapacity()
{
    return 0;
}

// Method for getting the ticket counter
public int getCounter()
{
    return 0;
}

// Method for setting the ticket counter
public void setCounter(int n)
{
    
}
// This is a method that overrides the toString method of the Object class to return a string representation of an instance of the Ticket class.
public String toString() 
{
    return "Name: " + name + ", Last Name: " + lastname +", National Code: " + nationalCode + ", Source: " + source + ", Destination: " + destination + ", Departure Time: " + departureTime.toString() + ", Price: " + price + ", Marker: " + marker;
}

}

// This is a subclass of the Ticket class named TrainTicket.
class TrainTicket extends Ticket 
{
// These are the constants that represent the capacity and the price of a train ticket, and the static variable that counts the number of train tickets sold.
    private static final int CAPACITY = 400;
    private static final int PRICE = 100;
    private static int traincounter = 0;

    // This is a constructor that creates a TrainTicket object with the given person, source, destination, and departure time and sets the marker using the setMarker method.
    public TrainTicket(Person person, String source, String destination, LocalDateTime departureTime) 
    {
       super(person,source,destination,departureTime);
        this.marker = setMarker();
    }
    
    // This is a method that returns the type of vehicle, which is "Train".
    public String getVehicleType()
    {
        return "Train";
    }

    // This is a method that returns the price of a train ticket.
    public int getPrice()
    {
        return PRICE;
    }

    // This is a method that returns the capacity of a train.
    public int getCapacity()
    {
        return CAPACITY;
    }

    // This is a method that returns the number of train tickets sold.
    public int getCounter()
    {
        return traincounter;
    }

    // This is a method that sets the number of train tickets sold to the given number.
    public void setCounter(int n)
    {
        traincounter = n;
    }
}

// This is a class named Person that represents a person with a name, a last name, and a national code.
class Person 
{
    // These are the fields that represent the name, the last name, and the national code of a person.
    protected String name;
    protected String lastname;
    protected int nationalCode;

    // This is a constructor that creates a Person object with the given name, last name, and national code.
    Person(String name, String lastname, int nationalcode) 
    {
        this.name = name;
        this.lastname = lastname;
        this.nationalCode = nationalcode;
    }

    // This is a method that returns the name of a person.
    public String getName() 
    {
        return name;
    }

    // This is a method that returns the last name of a person.
    public String getLastname() 
    {
        return lastname;
    }

    // This is a method that returns the national code of a person.
    public int getNationalcode() 
    {
        return nationalCode;
    }
}