package a5q4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Utility 
{
    
    public static <T extends Comparable<T>> T max(T[] arr) 
    {
        T max = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if (arr[i].compareTo(max) > 0) {
                max = arr[i];
            }
        }
        return max;
    }
    
    public static <T extends Comparable<T>> T min(T[] arr) 
    {
        T min = arr[0];
        for (int i = 1; i < arr.length; i++) 
        {
            if (arr[i].compareTo(min) < 0) 
            {
                min = arr[i];
            }
        }
        return min;
    }
    
    public static <T extends Comparable<T>> T[] removeRepetition(T[] arr) 
    {
        List<T> list = new ArrayList<T>();
        for (T elem : arr) {
            if (!list.contains(elem)) 
            {
                list.add(elem);
            }
        }
        T[] newArr = Arrays.copyOf(arr, list.size());
        return list.toArray(newArr);
    }
    
    public static Object max(Object[] arr) 
    {
        Object max = arr[0];
        for (int i = 1; i < arr.length; i++) 
        {
            if (((Comparable) arr[i]).compareTo(max) > 0) {
                max = arr[i];
            }
        }
        return max;
    }
    
    public static Object min(Object[] arr) 
    {
        Object min = arr[0];
        for (int i = 1; i < arr.length; i++) 
        {
            if (((Comparable) arr[i]).compareTo(min) < 0) {
                min = arr[i];
            }
        }
        return min;
    }
}
