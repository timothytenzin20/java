/*
*Author: Timothy Khan (1239165)
*Date: March 19, 2023
*Assignment 5: 4
*
*The purpose of this program is to create circles with a radius to be inputted. This is copied from a2q3to4 to be used by utility
*
*/
package a5q4;

public class Circle implements Comparable<Circle> 
{
    private double radius;

    // Constructor for Circle class
    public Circle(double radius) 
    {
        this.radius = radius;
    }

    // Getter for radius
    public double getRadius() 
    {
        return radius;
    }

    // Setter for radius
    public void setRadius(double radius) 
    {
        this.radius = radius;
    }

    // Implementation of the compareTo method from the Comparable interface
    @Override
    public int compareTo(Circle other) 
    {
        // Compare the radii of this Circle and the other Circle
        if (this.radius < other.radius) 
        {
            return -1; // this Circle is smaller than the other Circle
        } else if (this.radius > other.radius) 
        {
            return 1; // this Circle is larger than the other Circle
        } else {
            return 0; // the two Circles have the same radius
        }
    }
}
