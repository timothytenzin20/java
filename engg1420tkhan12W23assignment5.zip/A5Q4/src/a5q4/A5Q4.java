/*
*Author: Timothy Khan (1239165)
*Date: March 19, 2023
*Assignment 5: 2 to 3
*
* The purpose of this program is to make use of the student, circle, and utility classes and respective methods.
* as such, different objects are made and compared with the unique, largest, and smallest, being printed.
*
*/
package a5q4;

public class A5Q4 
{

public static void main(String[] args) 
{
    // create an array of Circle objects
    Circle[] circles = new Circle[4];
    circles[0] = new Circle(2.0);
    circles[1] = new Circle(3.0);
    circles[2] = new Circle(1.0);
    circles[3] = new Circle(4.0);

    // use the max and min methods to find the largest and smallest circles
    Circle largestCircle = Utility.max(circles);
    Circle smallestCircle = Utility.min(circles);

    System.out.println("The largest circle has a radius of " + largestCircle.getRadius());
    System.out.println("The smallest circle has a radius of " + smallestCircle.getRadius());

    // create an array of Student objects
    Student[] students = new Student[5];
    students[0] = new Student("John", "Doe", 1001, 3.5);
    students[1] = new Student("Jane", "Doe", 1002, 3.9);
    students[2] = new Student("Bob", "Smith", 1003, 3.2);
    students[3] = new Student("Alice", "Johnson", 1004, 3.7);
    students[4] = new Student("John", "Doe", 1005, 3.8);

    // use the removeRepetition method to remove duplicates from the array
    Student[] uniqueStudents = Utility.removeRepetition(students);

    // print out the unique students
    System.out.println("Unique students:");
    for (Student student : uniqueStudents) 
    {
        System.out.println(student.getFirstName() + " " + student.getLastName() + " (ID: " + student.getStudentNumber() + ")");
    }
}

}
