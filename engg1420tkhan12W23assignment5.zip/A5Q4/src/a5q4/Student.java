/*
*Author: Timothy Khan (1239165)
*Date: March 19, 2023
*Assignment 5: 2 to 3
*
* The purpose of this program is to create a student with the respective classes and methods. This is a copy from a5q2ti3 to be used by utility.
*/
package a5q4;

public class Student implements Comparable<Student> 
{
    private String firstName;
    private String lastName;
    private int studentNumber;
    private double gpa;

    // Constructor for Student class
    public Student(String firstName, String lastName, int studentNumber, double gpa) 
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.studentNumber = studentNumber;
        this.gpa = gpa;
    }

    // Getter for firstName
    public String getFirstName() 
    {
        return firstName;
    }

    // Setter for firstName
    public void setFirstName(String firstName) 
    {
        this.firstName = firstName;
    }

    // Getter for lastName
    public String getLastName() 
    {
        return lastName;
    }

    // Setter for lastName
    public void setLastName(String lastName) 
    {
        this.lastName = lastName;
    }

    // Getter for studentNumber
    public int getStudentNumber() 
    {
        return studentNumber;
    }

    // Setter for studentNumber
    public void setStudentNumber(int studentNumber) 
    {
        this.studentNumber = studentNumber;
    }

    // Getter for gpa
    public double getGpa() 
    {
        return gpa;
    }

    // Setter for gpa
    public void setGpa(double gpa) 
    {
        this.gpa = gpa;
    }

    // Implementation of the compareTo method from the Comparable interface
    @Override
    public int compareTo(Student other) 
    {
        // Check if the two Student objects are equal
        if (this.firstName.equals(other.firstName) &&
            this.lastName.equals(other.lastName) &&
            this.studentNumber == other.studentNumber &&
            this.gpa == other.gpa) 
        {
            return 0; // the two Student objects are equal
        } else if (this.gpa < other.gpa) 
        {
            return -1; // this Student has a lower GPA than the other Student
        } else {
            return 1; // this Student has a higher GPA than the other Student
        }
    }
}
