/*
*Author: Timothy Khan (1239165)
*Date: January 23, 2023
*Assignment 2: 1
*
*The purpose of the program is to output all prime numbers
*from 0 to 10,000 using if-else and while statements
*
*/
package question1;

public class Question1 {

    public static void main(String[] args) {
        // initialize variables
        int num = 0; // starting number
        
        // loop to check all numbers until 10000
        while (num <= 10000)
        {
            // initalize variables
            boolean prime = true; // default statement 
            int factor = 2; // check factors 
            
            // loop through all numbers until half the designated number
            while (factor <= num/2)
            {
                // if the number is divisible by any value of 'factor'
                if (num % factor == 0)
                {
                    prime = false; // update boolean value
                    break; // end loop
                }
                factor++; // move onto next next value
            }
            if (prime)
            {
                System.out.println (num); // print values
            }
            num++; // move onto next value
        }
    }
}
