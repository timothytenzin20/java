/*
*Author: Timothy Khan (1239165)
*Date: January 23, 2023
*Assignment 2: 2
*
*The purpose of the program is to output all prime numbers
*from 0 to 10,000 using switch-case and for statements
*
*/
package question2;

public class Question2 {

    public static void main(String[] args) {
        
        // loop through all numbers until 10000
        for (int num = 0; num <= 10000; num++)
        {
            // initialize variable
            boolean prime = true; // default boolean value to true
            // loop through all factors to check if prime or not
            for (int factor = 2; factor <= num/2; factor++)
            {
                // switch case to check if number is divisible
                switch (num % factor)
                {
                    // first case
                    case 0:
                        prime = false; // update boolean value
                        break; // end loop
                }
                // if not a prime number
                if (!prime)
                {
                    break;
                }
            }
            // if a prime number
            if (prime)
            {
                System.out.println(num); // print number stored
            }
        }   
    }
}

