/*
*Author: Timothy Khan (1239165)
*Date: January 23, 2023
*Assignment 2: 4
*
*The purpose of the program is to take user inputted
*integers and find their sum. The sum is calculated until
*integer value '0' is entered.
*
*/
package question4;

// Import scanner 
import java.util.Scanner;

public class Question4 
{

    public static void main(String[] args) 
    {
        //Scanner object to store user inputs
        Scanner scan = new Scanner(System.in); 
        
        // Initialize variable
        int sum = 0; // to store the sum of user entered integers

        // Loop to continuously add user inputted integers
        while (true)
        {
            // Prompt user to input an integer
            System.out.print("Input an integer to add (Enter 0 to stop): ");
            int numbers = scan.nextInt(); // scan and store inputted value
            
            if (numbers == 0) // Check if conditions to close loop is met
            {
                break;
            }
            // Add input to sum
            sum += numbers;
        }
        
        // Output sum of inputted numbers
        System.out.println("\nThe sum of all the inputted intgers is: " + sum);
    }

}