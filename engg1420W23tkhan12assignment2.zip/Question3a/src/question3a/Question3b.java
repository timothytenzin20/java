/*
*Author: Timothy Khan (1239165)
*Date: January 23, 2023
*Assignment 2: 3b
*
*The purpose of the program is to output specific symbols
*depending on integer values stored.
*
*/
package question3a;

public class Question3b {

    public static void main(String[] args) {
        // Initialize variables
        int y = 8; // condition value 1
        int x = 5; //  parameter value2
        
        // Check if y value stored matches requirements
        if (y == 8)
        {
            // Check if x value stored matches requirements
            if (x == 5)
            {
                System.out.println("@@@@@"); //Print if conditons met
            }
            else
            {
                System.out.println ("#####"); //Print default
                System.out.println("$$$$$"); // Print if conditions met
                System.out.println("&&&&&"); // Print if conditions met
            }
        }
    }
}