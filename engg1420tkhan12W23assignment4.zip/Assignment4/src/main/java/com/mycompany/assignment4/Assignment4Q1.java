/*
*Author: Timothy Khan (1239165)
*Date: February 13, 2023
*Assignment 4: 1
*
*The purpose of the program is to take a user inputted string, count the number 
*of consecutive occurences of each character in the string and prints the letter
*as well as the number of each occurence. This happens for all unique characters.
*
*/

package com.mycompany.assignment4;

import java.util.Scanner;

public class Assignment4Q1 
{
    public static void main(String[] args) 
    {
        // create a scanner object to read input from the user
        Scanner input = new Scanner(System.in);

        // initialize count and result variables
        int count = 1; // store occurances of character
        String result = ""; // store output
    
        // prompt user to enter a string
        System.out.println("Enter a string: ");
        String numberInput = input.nextLine();
        
        // iterate through the string
        for (int i = 1; i < (numberInput.length()); i++)
        {
            // if the current character matches the previous character
            if (numberInput.charAt(i) == numberInput.charAt(i-1))
            {
                // increment the count of consecutive characters
                count++;
            }
            else
            {
                // if the count of consecutive characters is greater than 1
                if (count > 1)
                {
                    // add the count and character to the result string
                    result += numberInput.charAt(i-1) + Integer.toString(count);
                }
                else
                {
                    // add just the character to the result string
                    result += numberInput.charAt(i-1);
                }
                // reset the count to 1
                count = 1;
            }
        }
        
        // handle the last character
        if (count > 1) 
        {
            result += numberInput.charAt(numberInput.length()-1) + Integer.toString(count);
        } 
        else 
        {
            result += numberInput.charAt(numberInput.length()-1);
        }
        
        // print the resulting string to the console
        System.out.println(result);
    }
}
