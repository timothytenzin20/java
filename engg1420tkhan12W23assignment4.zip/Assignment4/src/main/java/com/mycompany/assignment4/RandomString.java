/*
* Author: Timothy Khan (1239165)
* Date: February 13, 2023
* Assignment 4: 2
*
* The purpose of this program is to generate a random string of a user-specified length, containing letters 
* and digits in both upper and lower case. It uses the Random class to generate the random characters, and then
* prints the generated string to the console.
*
*/

package com.mycompany.assignment4;

import java.util.Scanner;
import java.util.Random;

public class RandomString {
    public int length; // store string length

    public RandomString(int x) {
        this.length = x; // indicate length is found from parameter x
    }

    public int nextString(int n) {
        Random rand = new Random(); // create scanner object
        String characterList = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvxyz" + "0123456789"; // store potential characters
        String output = ""; // store string output
        int c; // store random number
        n = this.length; // store string length
        
        // loop until string length reached, generating random characters each iteration
        for (int i = 0; i < length; i++) {
            if (i == 0) {
                c = rand.nextInt(52);
                output += characterList.charAt(c); // generate a random character and add it to output
            } else {
                c = rand.nextInt(62);
                output += characterList.charAt(c); // generate a random character and add it to output
            }
        }
        System.out.println(output); // print the final string
        return 0;
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int input; // store user input

        System.out.println("Enter a string length: ");
        input = scan.nextInt(); // read user input

        RandomString generate = new RandomString(input); // create new instance of RandomString class
        generate.nextString(input); // call nextString method to generate the random string
    }
}
