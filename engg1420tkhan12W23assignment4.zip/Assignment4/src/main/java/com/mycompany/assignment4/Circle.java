/*
* Author: Timothy Khan (1239165)
* Date: February 13, 2023
* Assignment 4: 6-8
*
* The purpose of the program is to take a user inputted circle radii and generate circles, adding them as well as
* dissecting their total into separate circles.
*
*/

package com.mycompany.assignment4;

import java.util.ArrayList;
import java.util.Random;

public class Circle 
{

    private double radius;

    public Circle(double radius) 
    {
        this.radius = radius; // store radius
    }

    public void add(Circle other) 
    {
        this.radius += other.radius;
    }

    public void addAll(Circle[] circles) 
    {
        for (Circle c : circles) 
        {
            this.add(c); // add all circle values together
        }
    }

    public double getRadius() 
    {
        return this.radius;
    }

    // decompose method to decompose the circle into a set of circles with radius 2^n, n = 0, 1, 2, ...
    public Circle[] decompose() 
    {
        ArrayList<Circle> circlesList = new ArrayList<Circle>();
        Circle copy = new Circle(this.radius); // create new circle

        while (copy.radius > 1) 
        {
            int n = (int) (Math.log(copy.radius) / Math.log(2)); // randomize radius
            int r = (int) Math.pow(2, n); // apply circle calculations

            Circle c = new Circle(r);
            circlesList.add(c);

            copy.radius -= r;
        }

        Circle c = new Circle(copy.radius);
        circlesList.add(c);

        Circle[] circlesArray = new Circle[circlesList.size()];
        circlesArray = circlesList.toArray(circlesArray);
        return circlesArray;
    }

    // run methods and perform tasks
    public static void main(String[] args) 
    {
        Circle[] circles = new Circle[100];
        for (int i = 0; i < 100; i++) 
        {
            circles[i] = new Circle(i + 1);
        }

        Random rand = new Random();
        double cRadius = rand.nextInt(991) + 10;
        Circle c = new Circle(cRadius);

        System.out.println("Before adding circles, C radius = " + c.getRadius());

        c.addAll(circles);

        System.out.println("After adding circles, C radius = " + c.getRadius());

        Circle[] decomposedCircles = c.decompose();
        System.out.println("Decomposed circles: ");
        for (Circle circle : decomposedCircles) 
        {
            System.out.println(circle.getRadius());
        }
    }
}
