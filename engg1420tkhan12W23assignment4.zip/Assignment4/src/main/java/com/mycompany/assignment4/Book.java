/*
* Author: Timothy Khan (1239165)
* Date: February 13, 2023
* Assignment 4: 3 and 4
*
* The purpose of this program is to generate a random string of a user-specified length, containing letters 
* and digits in both upper and lower case. It uses the Random class to generate the random characters, and then
* prints the generated string to the console.
*
*/

// Importing Scanner class for user input
import java.util.Scanner;

// Book class definition
public class Book
{
    // Private variables of the Book class
    private String title; // store title
    private String authors; // store authors
    private int numPages; // store page count
    private int year; // store year of publishing
    private double price; // price of book

    // Constructor for Book class with all arguments
    public Book(String title, String authors, int numPages, int year, double price) 
    {
        this.title = title;
        this.authors = authors;
        this.numPages = numPages;
        this.year = year;
        this.price = price;
    }

    // Constructor for Book class with title, authors and number of pages as arguments
    public Book(String title, String authors, int numPages) {
        this.title = title;
        this.authors = authors;
        this.numPages = numPages;
    }

    // Constructor for Book class with only title and authors as arguments
    public Book(String title, String authors) 
    {
        this.title = title;
        this.authors = authors;
    }

    // Method to return title in title case
    public String getTitleInTitleCase() 
    {
        // Splitting the title by spaces and storing in an array
        String[] words = title.toLowerCase().split(" ");
        // Using StringBuilder to efficiently construct the result string
        StringBuilder result = new StringBuilder();
        // Looping through the words and appending them to the result string in title case
        for (String word : words) {
            result.append(word.substring(0, 1).toUpperCase());
            result.append(word.substring(1));
            result.append(" ");
        }
        // Printing the result and returning it as a string
        System.out.println(result);
        return result.toString();
    }

    // Method to check if a given string is present in the title
    public boolean contains(String str) 
    {
        // Converting the search string to lowercase for case-insensitive comparison
        String check = str; // store string inputted
        boolean checker = false; // store boolean statement

        // Looping through each character of the title to find a potential match
        for (int i = 0; i < title.length(); i++) 
        {
            // If the first character matches, checking if the subsequent characters match
            if (title.toLowerCase().charAt(i) == str.toLowerCase().charAt(0) || title.charAt(i) == str.charAt(0)) 
            {
                int count = i;
                for (int j = 1; j < str.length(); j++, count++) 
                {
                    if (title.toLowerCase().charAt(count + 1) == str.toLowerCase().charAt(j)) 
                    {
                        checker = true;
                    }
                    else 
                    {
                        checker = false;
                    }
                }
            }
        }
        // Printing the result and returning it
        if (checker == true) 
        {
            System.out.println("True");
        } else 
        {
            System.out.println("False");
        }
        return checker;
    }

    // Method to print all authors of the book
    public void printAuthors() 
    {
        // Splitting the authors string by commas and storing in an array
        String[] authorsList = authors.split(",");
        // Using StringBuilder to efficiently construct the result string
        StringBuilder result = new StringBuilder();

        // Counting the number of authors by
        int count = 0; // initialize counter to 0
        char comma = 44; // comma character (ASCII code 44)
        for (int j = 1; j < (authors.length()); j++) // loop through each character in authors string
        {
            if (authors.charAt(j) == comma) // check if the current character is a comma
            {
            count++; // if it is, increment the counter
            }
        }

        for (int i = 0; i <= count; i++)
        { // loop through each author name
        System.out.println (authorsList[i]); // print the current author name
        }
    }

    public static void main(String[] args) 
    {
        // initialize variables
        String title; // store title input
        String authors; // store authors input
        int numPages; // store page count input
        int year; // store publishing year input
        double price; // store book price input
        String wordFind; // store word to be found input

        Scanner input = new Scanner(System.in);

        System.out.println ("Enter the title: ");
        title = input.nextLine(); // read user input for title
        System.out.println ("Enter the authors name(s): ");
        authors = input.nextLine(); // read user input for authors
        System.out.println ("Enter the number of pages: ");
        numPages = input.nextInt(); // read user input for number of pages
        System.out.println ("Enter the publishing year: ");
        year = input.nextInt(); // read user input for publishing year
        System.out.println ("Enter the the books price: ");
        price = input.nextDouble(); // read user input for book price
        System.out.println ("Enter a word to search the title for: ");
        wordFind = input.next(); // read user input for word to search in title


        Book book1 = new Book(title, authors, numPages, year, price); // create a new Book object
        book1.getTitleInTitleCase(); // call getTitleInTitleCase method on book1 object
        book1.contains(wordFind); // call contains method on book1 object, passing wordFind as argument
        book1.printAuthors(); // call printAuthors method on book1 object
    } 
}
