
package com.mycompany.assignment4;

import java.util.Scanner;


public class Assignment4Q5 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the emails: ");
        String input = scanner.nextLine();

        // Count the number of email addresses that have the _ character.
        int countUnderscore = 0;

        // Count the number of email addresses associated with Gmail.
        int countGmail = 0;

        // Count the number of email addresses that have both _ character and associated with Gmail.
        int countBoth = 0;

        String[] emails = input.split("[;,\\s]+"); // split input by semicolons, commas, or space
        for (String email : emails) {
            if (email.contains("_")) {
                countUnderscore++;
            }
            if (email.endsWith("@gmail.com")) {
                countGmail++;
            }
            if (email.contains("_") && email.endsWith("@gmail.com")) {
                countBoth++;
            }
        }

        System.out.println("Number of email addresses that have the _ character: " + countUnderscore);
        System.out.println("Number of email addresses associated with Gmail: " + countGmail);
        System.out.println("Number of email addresses that have both _ character and associated with Gmail: " + countBoth);
    }
}
